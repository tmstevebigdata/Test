How to use the Bash Shell scripts to automate the process of:-

1) Clone from Github

and

2) Push to Github


There are 2 scripts in this folder ie.

1) 1-CloneFromGitHub-RepoName.sh

2) 2-Push2GitHub-RepoName.sh


Before you can use these scripts you need to do the following:-

1) Create a folder in your C: drive and call it C:\GitHub
   Note: If you already done this then ignore this step

2) Create a Repo in Github
   Note: If you already done this then ignore this step


How to modify the scripts for use:-

Modify 1-CloneFromGitHub-RepoName.sh

1) Open 1-CloneFromGitHub-RepoName.sh with Notepad

2) Search and Replace RepoName with the name of your Github Repo Name

3) Search and Replace RepoID with the your Github RepoID

4) Search and Replace UserEmail with the Email Address you used when registering your Github Acct

5) Save and Run

Note: You only need to do this once.

Modify 2-Push2GitHub-RepoName.sh

1) Open 2-Push2GitHub-RepoName.sh with Notepad

2) Search and Replace RepoName with the name of your Github Repo Name

3) Search and Replace RepoID with the your Github RepoID

4) Search and Replace UserEmail with the Email Address you used when registering your Github Acct

5) Search and Replace RepoPSW with your Github Repo Password

6) Save and Run

Note: Everytime you modify your local Github folder you need to run this script to push and commit your changes to your Github repository.

Note and Disclaimer:
1) If you screw up not my problem since I give this to you freely.
2) I don't provide support for these scripts - Please learn on your own via Google - That's how I did it myself.

~ END ~
